let users = [
  { id: 1, name: "Jyothi" },
  { id: 2, name: "Chinni" }
];

module.exports = users;
