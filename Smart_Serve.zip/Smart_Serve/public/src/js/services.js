async function loadServices() {
  const res = await fetch("data/services.json");
  const services = await res.json();

  document.getElementById("serviceList").innerHTML =
    services.map(s => `
      <div class="card p-3">
        <h5>${s.name}</h5>
        <p>₹${s.price}</p>
      </div>
    `).join("");
}
