const app = document.getElementById("app");

const pages = {
  home: `
    <h2>Welcome to SmartServe</h2>
    <p>Find trusted local services.</p>
  `,
  services: `
    <h2>Services</h2>
    <div id="serviceList" class="service-grid"></div>
  `,
  book: `
    <h2>Book Service</h2>
    <input class="form-control mb-2" placeholder="Your Name">
    <button class="btn btn-primary">Submit</button>
  `
};

document.querySelectorAll("[data-page]").forEach(link => {
  link.onclick = e => {
    e.preventDefault();
    loadPage(e.target.dataset.page);
  };
});

function loadPage(page) {
  app.innerHTML = pages[page];
  if (page === "services") loadServices();
}

loadPage("home");
