interface ServiceRequest {
    name :string;
    email :string;
    service : string;

}

let r:ServiceRequest = {
    name : "Jyothi Sree",
    email :"jyothisreethanikonda44@gmailcom",
    service: "Web"
};